# The-Data-Scientist
A brief summary of my Coursera Data Science specialization experience  
Exploratory Analysis (http://rpubs.com/MBravo/18514)  
Capstone Project Milestone report (http://rpubs.com/MBravo/41432)  
Capstone Project Presentation (http://rpubs.com/MBravo/48949)  
Capstone Project Application: Next Word Predictor (https://mbravo.shinyapps.io/PredictorApp/)  
